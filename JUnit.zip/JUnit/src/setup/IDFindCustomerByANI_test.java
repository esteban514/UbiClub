package setup;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.Test;

import com.nuance.bofa.dataaccess.Constants;

import parser.JSONParser;
import simulator.CallSimulator;
import simulator.CallSimulatorSetup;
import simulator.Util;

/**
 * @author esteban_fernandez
 *	Testing ID Customer by ANI 
 *	514 904 7800 : UT Task 6 Jason
 *	514 904 7801 : UT Task 6 Janet
 *	514 904 7802 : Has Fraud Claim Mike 
 */
@SuppressWarnings("unchecked")
public class IDFindCustomerByANI_test {
	@Test
    public void Janet() throws Throwable {
    	
    	HashMap<String, String> returnMap = new HashMap<String, String>();
    	
    	CallSimulator.Start();
    	
    	Util.WriteTofile(CallSimulatorSetup.IDFindCustomerByANI("1070001","5149047801", "Card", "anything","90").toString(), "temp");
    	
    	returnMap = CallSimulatorSetup.IDFindCustomerByANI("1070001","5149047801", "Card", "anything","90");
       	
    	assertTrue(returnMap.get(Constants.RETURN_CODE).equals("0"));	
	 	assertTrue(String.valueOf( returnMap.get("lastFourAccountNumbersUnique")).equals("true"));
		assertTrue(String.valueOf( returnMap.get("lastFourSSNUniqueFlag")).equals("true"));

		JSONArray array = (JSONArray)JSONParser.getArray((JSONObject) (returnMap),"partyIdInformation");
		HashMap<String, String> informationMap = ((JSONObject) array.get(0));
		
		assertTrue(String.valueOf( informationMap.get("fistName")).equals("Janet"));
		assertTrue(String.valueOf( informationMap.get("partyId")).equals("404927634"));
		assertTrue( informationMap.get("namePrompt").equals("gen1005_out_09"));
		
		array = (JSONArray)JSONParser.getArray((JSONObject) (returnMap),"accountNumberInformation");
		informationMap = ((JSONObject) array.get(0));
		
		assertTrue(String.valueOf( informationMap.get(Constants.INPUT_ACCOUNT_NUMBER) ).equals("4940045676191513"));
	}
	@Test
    public void Jason() throws Throwable {
    	
    	HashMap<String, String> returnMap = new HashMap<String, String>();
    	
    	CallSimulator.Start();
    	Util.WriteTofile(CallSimulatorSetup.IDFindCustomerByANI("1070001","5149047800", "Card", "anything","90").toString(), "temp");
    	
    	returnMap = CallSimulatorSetup.IDFindCustomerByANI("1070001","5149047800", "Card", "anything","90");
    		
    	assertTrue(returnMap.get(Constants.RETURN_CODE).equals("0"));	
	 	assertTrue(String.valueOf( returnMap.get("lastFourAccountNumbersUnique")).equals("true"));
		assertTrue(String.valueOf( returnMap.get("lastFourSSNUniqueFlag")).equals("true"));

		JSONArray array = (JSONArray)JSONParser.getArray((JSONObject) (returnMap),"partyIdInformation");

		HashMap<String, String> informationMap = ((JSONObject) array.get(0));
		
		assertTrue(String.valueOf( informationMap.get("fistName")).equals("Jason"));
		assertTrue( informationMap.get("namePrompt").equals("gen1005_out_30"));
		
		array = (JSONArray)JSONParser.getArray((JSONObject) (returnMap),"accountNumberInformation");
		informationMap = ((JSONObject) array.get(0));
		
		assertTrue(String.valueOf( informationMap.get(Constants.INPUT_ACCOUNT_NUMBER) ).equals("4716117564462421"));
	}
}