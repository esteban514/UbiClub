package simulator;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;

import org.xml.sax.SAXException;

import parser.ResponseParser;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.meterware.httpunit.HttpUnitOptions;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;

/**
 * @author esteban_fernandez
 *
 */
public class CallSimulator {
	
   private static WebConversation _webConversation; 
   
   public static void Start() throws IOException, SAXException{
	   _webConversation = new WebConversation();		
		HttpUnitOptions.setScriptingEnabled(false);
		_webConversation.getResponse(CallSimulatorConstants.BASE_URL+CallSimulatorConstants.INIT_URL);
    }
 	
   public static void send(String URL) 
   		throws FailingHttpStatusCodeException, MalformedURLException, IOException, SAXException{  	
       _webConversation.getResponse(URL);
   }
   
   public static WebResponse getResponse(String URL) 
    		throws FailingHttpStatusCodeException, MalformedURLException, IOException, SAXException{  	
        return _webConversation.getResponse(URL);
    }
   
   public static  HashMap<String, String>  getResponseMap(String URL) 
   		throws Throwable{  	
       return ResponseParser.getReturnMap(ResponseBuffer.getResponseBuffer(getResponse(URL)));
   }

}