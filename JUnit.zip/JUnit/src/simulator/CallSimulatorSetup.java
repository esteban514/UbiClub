package simulator;

import java.util.HashMap;
import java.util.Random;

public class CallSimulatorSetup {
	 public static HashMap<String, String>  IDFindCustomerByANI(String DNIS, String ANI, String LOB, String TYPE, String ISSUER) throws Throwable {
		 
		   String accessor = "GetDNISInfo";    	
		   HashMap<String, String>   map = new HashMap<String, String>();
		   map .put("dnis", DNIS);
		   map.put("sessionID", String.valueOf( new Random().nextInt() ) );    	
	   
		   CallSimulator.send(Util.generateURL( accessor , map ));

		   map.clear();

		   accessor = "ANIFraudLookup";    	
		   map.put("ani",ANI);
		   map.put("lobCode",LOB);  

		   CallSimulator.send(Util.generateURL( accessor , map ));

		   map.clear();

		   accessor = "IDFindCustomerByANI";    
		   map.put("ani",ANI);
		   map.put("typeOfSearch",LOB);
		   map.put("issuerNumber",ISSUER);  

		   return ( CallSimulator.getResponseMap( Util.generateURL( accessor, map) ) );
	}
}
