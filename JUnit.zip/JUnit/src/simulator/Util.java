package simulator;

import java.io.FileWriter;
import java.util.Iterator;
import java.util.Map;

public class Util {

	
	public static void WriteTofile(String text, String title) throws Throwable{
		FileWriter fw = new FileWriter(title+".xml",false); 	
		fw.write(text);	
		fw.close();

	}
	   @SuppressWarnings("rawtypes")
	   public static String generateURL(String AccessorName, Map<String, String> Parameters){
		   Iterator it = Parameters.entrySet().iterator();
		   String URL = CallSimulatorConstants.BASE_URL + AccessorName + "." + CallSimulatorConstants.DATACCESS + "?";
		   while (it.hasNext()){
			   Map.Entry pairs = (Map.Entry)it.next();
			   URL = URL + pairs.getKey() + "=" + pairs.getValue();
			   if (it.hasNext()){
				   URL = URL + "&";
			   } 	
	    	}
		   return URL;
	   	}
}
