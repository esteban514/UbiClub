package simulator;

import java.io.ByteArrayInputStream;

import com.meterware.httpunit.WebResponse;

public class ResponseBuffer{

private static ByteArrayInputStream _responseBuffer; 
	
	public static ByteArrayInputStream getResponseBuffer(WebResponse response) throws Throwable{  	
			setResponseBuffer(response);
	   return _responseBuffer;
	}
	private static void setResponseBuffer(WebResponse response) throws Throwable {
		_responseBuffer = new ByteArrayInputStream(response.getText().getBytes());
	}
}
