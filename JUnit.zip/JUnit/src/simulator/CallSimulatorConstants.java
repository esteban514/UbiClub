
package simulator;

public class CallSimulatorConstants {
	public static final String BASE_URL = "http://localhost:8080/IVPIVR/";//17.115
	public static final String INIT_URL = "stub?ClientType=stub";
	public static final String DATACCESS = "dataaccess";
	public static final String DOT_DATACCESS_MARK = ".dataaccess?";
}
