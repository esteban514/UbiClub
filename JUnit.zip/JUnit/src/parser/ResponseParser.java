package parser;

import java.io.ByteArrayInputStream;
import java.util.HashMap;

import org.json.simple.JSONObject;

public class ResponseParser {	
	@SuppressWarnings("unchecked")
	public static HashMap<String, String> getReturnMap(ByteArrayInputStream response) throws Throwable{
		return getJsonObject(getResponse(response));
	}
	private static JSONObject getJsonObject(String s){
		return (JSONObject) JSONParser.getObject(s);
	}
	private static String getResponse(ByteArrayInputStream inputStream) throws Throwable{
		return XMLParser.parseXMLForJsonString(inputStream);
	}
}
