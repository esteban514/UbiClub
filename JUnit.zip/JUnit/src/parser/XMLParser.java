package parser;
import java.io.ByteArrayInputStream;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XMLParser {	
	private static final String JSON = "json";
	private static final int INDEX_ZERO = 0;
	
	public static String parse(ByteArrayInputStream inputStream, String value, String element) throws ParserConfigurationException, Exception, Throwable {	
		return getValue( getElement ( getDocument( inputStream  ) ), 0);
	}
	private static Document getDocument(ByteArrayInputStream inputStream) throws Throwable, Exception, ParserConfigurationException{
		return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(inputStream);
	}
	private static Element getElement(Document doc){
		return doc.getDocumentElement();
	}
	private static String getValue(Element eElement, Integer index) {
		return eElement.getElementsByTagName(JSON).item(index).getTextContent();
	}
	public static String parseXMLForJsonString(ByteArrayInputStream inputStream) throws Throwable {
		return getValue( getElement ( getDocument( inputStream  ) ));
	}
	private static String getValue(Element element) {
		return element.getElementsByTagName(JSON).item(INDEX_ZERO).getTextContent();
	}
}


