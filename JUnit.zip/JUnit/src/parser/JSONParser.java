package parser;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class JSONParser {
	/**
	 * @param args
	 */
	public static Object getObject(String s){
		JSONObject object;
		object=(JSONObject) JSONValue.parse(s);
		return object;
	}
	public static JSONArray getArray(JSONObject object, String key){
		JSONArray array;
		array=(JSONArray) object.get(key);
		return array;
	}
}
