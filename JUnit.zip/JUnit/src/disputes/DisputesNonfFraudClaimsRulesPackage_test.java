package disputes;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;

import org.junit.Test;

import simulator.CallSimulator;
import simulator.CallSimulatorSetup;
import simulator.Util;

import com.nuance.bofa.dataaccess.Constants;


/**
 * @author esteban_fernandez
 * 
 * Inputs: disputeInd, contextDnisKey, callerIntent
 * Outputs: returnCode, disputeRuleResult, callerIntent
 * 
 * TODO: Add Updated Caller Intent 
 * 
 * Called in: disp1025_NonFraudClaims_RP_DB
 */
public class DisputesNonfFraudClaimsRulesPackage_test {
	/*		
		<dnis>1070001</dnis>
		<dnisKey>CardCustSatBrand</dnisKey>
	*/
	String accessor;
	@Test
    public void CardCustSatBrand() throws Throwable {

		HashMap<String, String> inputMap = new HashMap<String, String>();
		HashMap<String, String> returnMap = new HashMap<String, String>();
		
		// Set up call
		String dnis = "1070001";
		String ani = "5149047801";
		String lob = "Card";
		String searchType = "anything";
		String entityCode = "90";
		
		CallSimulator.Start();
		CallSimulatorSetup.IDFindCustomerByANI(dnis,ani,lob,searchType,entityCode);
		
		String disputeInd = "T";
		String contextDnisKey = dnis;
		String callerIntent = "Disputes";
		
		// Disputes Non Fraud Claims Rules Package
		accessor = "DisputesNonFraudClaimsRulesPackage";   
		inputMap.put(Constants.INPUT_DISPUTE_IND,disputeInd);
		inputMap.put(Constants.INPUT_DNIS_KEY, contextDnisKey);
		inputMap.put(Constants.INPUT_CALLER_INTENT ,callerIntent);  
		
		// Parse response
		returnMap = ( CallSimulator.getResponseMap( Util.generateURL( accessor , inputMap ) ) );
		
		assertTrue(returnMap.get("returnCode").equals("0"));
		assertTrue(returnMap.get(Constants.OUTPUT_DISPUTE_RULE_RESULT).equals(Constants.DISPUTES_RULE_RESULT_EXISTING));	
	}
	/*		
		<dnis>1071892</dnis>
		<dnisKey>CardNonFraudClaimsLetter</dnisKey>
	*/
	@Test
    public void CardNonFraudClaimsLetter() throws Throwable {

    	HashMap<String, String> inputMap = new HashMap<String, String>();
		HashMap<String, String> returnMap = new HashMap<String, String>();
  		// Set up call
  		String dnis = "1071892";
  		String ani = "5149047801";
  		String lob = "Card";
  		String searchType = "anything";
  		String entityCode = "90";
  		
  		CallSimulator.Start();
  		CallSimulatorSetup.IDFindCustomerByANI(dnis,ani,lob,searchType,entityCode);
  		
  		String disputeInd = "!T";
  		String contextDnisKey = dnis;
  		String callerIntent = "Disputes";
  				
  		// Disputes Non Fraud Claims Rules Package
  		accessor = "DisputesNonFraudClaimsRulesPackage";   
  		inputMap.put(Constants.INPUT_DISPUTE_IND,disputeInd);
  		inputMap.put(Constants.INPUT_DNIS_KEY,contextDnisKey);
  		inputMap.put(Constants.INPUT_CALLER_INTENT,callerIntent);  
  		
  		// Parse response
  		returnMap = ( CallSimulator.getResponseMap( Util.generateURL( accessor , inputMap ) ) );

  		assertTrue(returnMap.get("returnCode").equals("0"));
  		assertTrue(returnMap.get(Constants.OUTPUT_DISPUTE_RULE_RESULT).equals(Constants.DISPUTES_RULE_RESULT_EXISTING));	
  	} 	 
	/*	
		<dnis>1071171</dnis>
		<dnisKey>CardNonFraudClaimsStmtBack</dnisKey>
	*/
	@Test
    public void CardNonFraudClaimsStmtBack() throws Throwable {
  	
    	HashMap<String, String> inputMap = new HashMap<String, String>();
		HashMap<String, String> returnMap = new HashMap<String, String>();
  		// Set up call
  		String dnis = "1071171";
  		String ani = "5149047801";
  		String lob = "Card";
  		String searchType = "anything";
  		String entityCode = "90";
  		
  		CallSimulator.Start();
  		CallSimulatorSetup.IDFindCustomerByANI(dnis,ani,lob,searchType,entityCode);
  		
  		String disputeInd = "!T";
  		String contextDnisKey = dnis;
  		String callerIntent = "Disputes";
  	
  		// Disputes Non Fraud Claims Rules Package
  		accessor = "DisputesNonFraudClaimsRulesPackage";   
  		inputMap.put(Constants.INPUT_DISPUTE_IND,disputeInd);
  		inputMap.put(Constants.INPUT_DNIS_KEY,contextDnisKey);
  		inputMap.put(Constants.INPUT_CALLER_INTENT,callerIntent);  
  		
  		// Parse response
  		returnMap = ( CallSimulator.getResponseMap( Util.generateURL( accessor , inputMap ) ) );
	
  		assertTrue(returnMap.get("returnCode").equals("0"));
  		assertTrue(returnMap.get(Constants.OUTPUT_DISPUTE_RULE_RESULT).equals(Constants.DISPUTES_RULE_RESULT_NEW));	
  	} 
	/*	
		<dnis>1071181</dnis>
		<dnisKey>CardNonFraudClaimsStatus</dnisKey>
	 */
	@Test
    public void CardNonFraudClaimsStatus() throws Throwable {
  	
    	HashMap<String, String> inputMap = new HashMap<String, String>();
		HashMap<String, String> returnMap = new HashMap<String, String>();
  		// Set up call
  		String dnis = "1071181";
  		String ani = "5149047801";
  		String lob = "Card";
  		String searchType = "anything";
  		String entityCode = "90";
  		
  		CallSimulator.Start();
  		CallSimulatorSetup.IDFindCustomerByANI(dnis,ani,lob,searchType,entityCode);
  		
  		String disputeInd = "!T";
  		String contextDnisKey = dnis;
  		String callerIntent = "Disputes";
  				
  		// Disputes Non Fraud Claims Rules Package
  		accessor = "DisputesNonFraudClaimsRulesPackage";   
  		inputMap.put(Constants.INPUT_DISPUTE_IND,disputeInd);
  		inputMap.put(Constants.INPUT_DNIS_KEY,contextDnisKey);
  		inputMap.put(Constants.INPUT_CALLER_INTENT,callerIntent);  
  		
  		// Parse response
  		returnMap = ( CallSimulator.getResponseMap( Util.generateURL( accessor , inputMap ) ) );

  		assertTrue(returnMap.get("returnCode").equals("0"));
  		assertTrue(returnMap.get(Constants.OUTPUT_DISPUTE_RULE_RESULT).equals(Constants.DISPUTES_RULE_RESULT_NEW));	
  	} 
	@Test
    public void dnisKeyNotFound() throws Throwable {
  	
    	HashMap<String, String> inputMap = new HashMap<String, String>();
		HashMap<String, String> returnMap = new HashMap<String, String>();
  		// Set up call
  		String dnis = "1071171";
  		String ani = "5149047801";
  		String lob = "Card";
  		String searchType = "anything";
  		String entityCode = "90";
  		
  		CallSimulator.Start();
  		CallSimulatorSetup.IDFindCustomerByANI(dnis,ani,lob,searchType,entityCode);
  		
  		String disputeInd = "Y";
  		String contextDnisKey = "120asdfg";
  		String callerIntent = "Disputes";
  				
  		// Disputes Non Fraud Claims Rules Package
  		accessor = "DisputesNonFraudClaimsRulesPackage";   
  		inputMap.put(Constants.INPUT_DISPUTE_IND,disputeInd);
  		inputMap.put(Constants.INPUT_DNIS_KEY,contextDnisKey);
  		inputMap.put(Constants.INPUT_CALLER_INTENT,callerIntent);  
  		
  		// Parse response
  		returnMap = ( CallSimulator.getResponseMap( Util.generateURL( accessor , inputMap ) ) );
  
  		assertTrue(returnMap.get("returnCode").equals("0"));
  		assertTrue(returnMap.get(Constants.OUTPUT_DISPUTE_RULE_RESULT).equals("undefined"));	
  	} 
}

	