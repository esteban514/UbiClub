package disputes;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.util.Random;

import org.junit.Test;

import com.meterware.httpunit.GetMethodWebRequest;
import com.meterware.httpunit.HttpUnitOptions;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;


import org.json.simple.*;

import parser.JSONParser;
import parser.XMLParser;
import simulator.CallSimulatorConstants;

public class Disp1110_GetReferenceNum_DM_custom_DA_test {

	@Test
    public void ReferenceNumberFound_4940045676191513() throws Throwable {
    	// 
		WebConversation wc = new WebConversation();		
		// Avoid EcmaError: ReferenceError: "model" is not defined
		HttpUnitOptions.setScriptingEnabled(false);
	
		// Initial URL
	    GetMethodWebRequest     req = new GetMethodWebRequest( CallSimulatorConstants.BASE_URL+ CallSimulatorConstants.INIT_URL );
	    WebResponse resp = wc.getResponse( req );
	    
	    // Call Set Up
	    req = new GetMethodWebRequest(  CallSimulatorConstants.BASE_URL+"GetDNISInfo"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"dnis=1070001&sessionID="+(new Random()).nextInt() );
	    resp = wc.getResponse( req );
	    req = new GetMethodWebRequest(  CallSimulatorConstants.BASE_URL+"ANIFraudLookup"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"ani=5149047801&lobCode=Card" );
	    resp = wc.getResponse( req );
	    req = new GetMethodWebRequest(  CallSimulatorConstants.BASE_URL+"IDFindCustomerByANI"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"ani=5149047801&typeOfSearch=lob&issuerNumber=90" );
	   
	    // Disputes
	    req = new GetMethodWebRequest(  CallSimulatorConstants.BASE_URL+"DisputesRetrieveTransactionHistory"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"accountNumber=4940045676191513&sessionID=1070001&entityCode=90" );
	   	resp = wc.getResponse( req );
		req = new GetMethodWebRequest(   CallSimulatorConstants.BASE_URL+"Disp1110_GetReferenceNum_DM_custom_DA"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"refNum=0301" );
		resp = wc.getResponse( req );

		// Parse Response
	 	JSONObject object = (JSONObject) JSONParser.getObject(XMLParser.parse(new ByteArrayInputStream(resp.getText().getBytes()), "json","response"));
		
 		assertTrue(object.get("returnCode").equals("0"));
 		assertTrue(object.get("merchantMessage").equals("ra7015R_out_192"));
 		assertTrue(object.get("transactionAmount").equals("120.50"));
 		assertTrue(object.get("merchantCategoryCode").equals("0742"));
 		assertTrue(object.get("transactionDate").equals("20130821"));
    }
	@Test
    public void ReferenceNumberFound_4716117564462421() throws Throwable {
    	
		WebConversation wc = new WebConversation();		
		// Avoid EcmaError: ReferenceError: "model" is not defined
		HttpUnitOptions.setScriptingEnabled(false);
	
		// Initial URL
	    GetMethodWebRequest     req = new GetMethodWebRequest( CallSimulatorConstants.BASE_URL+ CallSimulatorConstants.INIT_URL );
	    WebResponse resp = wc.getResponse( req );
	    
	    // Call Set Up
	    req = new GetMethodWebRequest(  CallSimulatorConstants.BASE_URL+"GetDNISInfo"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"dnis=1070001&sessionID="+(new Random()).nextInt() );
	    resp = wc.getResponse( req );
	    req = new GetMethodWebRequest(  CallSimulatorConstants.BASE_URL+"ANIFraudLookup"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"ani=5149047800&lobCode=Card" );
	    resp = wc.getResponse( req );
	    req = new GetMethodWebRequest(  CallSimulatorConstants.BASE_URL+"IDFindCustomerByANI"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"ani=5149047800&typeOfSearch=lob&issuerNumber=90" );
	   
	    // Disputes
	    req = new GetMethodWebRequest(  CallSimulatorConstants.BASE_URL+"DisputesRetrieveTransactionHistory"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"accountNumber=4716117564462421&sessionID=1070001&entityCode=90" );
	   	resp = wc.getResponse( req );
		req = new GetMethodWebRequest(   CallSimulatorConstants.BASE_URL+"Disp1110_GetReferenceNum_DM_custom_DA"+ CallSimulatorConstants.DOT_DATACCESS_MARK+"refNum=0301" );
		resp = wc.getResponse( req );

		// Parse Response
	 	JSONObject object = (JSONObject) JSONParser.getObject(XMLParser.parse(new ByteArrayInputStream(resp.getText().getBytes()), "json","response"));
		
 		assertTrue(object.get("returnCode").equals("0"));
 		assertTrue(object.get("merchantMessage").equals("ra7015R_out_192"));
 		assertTrue(object.get("transactionAmount").equals("120.50"));
 		assertTrue(object.get("merchantCategoryCode").equals("0742"));
 		assertTrue(object.get("transactionDate").equals("20130821"));
    }
}

/*
 * 	 
	FileWriter fw = new FileWriter("temp.xml",false); 
	fw.write(resp.getText());
	fw.close();
	
	//		JSONObject object = (JSONObject) JSONParser.getObject(XMLParser.parse(new File("temp.xml"),"json"));assertTrue(new File("temp.xml").delete());
 */

