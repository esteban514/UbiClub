package fraud;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;

import org.junit.Test;

import simulator.CallSimulator;
import simulator.CallSimulatorSetup;
import simulator.Util;

import com.nuance.bofa.dataaccess.Constants;


/**
 * @author esteban_fernandez
 * 
 * Inputs: disputeInd, contextDnisKey, callerIntent
 * Outputs: returnCode, disputeRuleResult, callerIntent
 * 
 * TODO: Add Updated Caller Intent 
 * 
 * Called in: disp1025_NonFraudClaims_RP_DB
 */
public class TransactionHistoryRetrieveArrangementDetails_test {

	String accessor;
	@Test
    public void HasLostStolen_4520333344445555() throws Throwable {

		HashMap<String, String> inputMap = new HashMap<String, String>();
		HashMap<String, String> returnMap = new HashMap<String, String>();
		
		// Set up call
		String dnis = "1070001";
		String ani = "5149047802";
		String lob = "Card";
		String searchType = "anything";
		String entityCode = "90";
		
		CallSimulator.Start();
		returnMap = CallSimulatorSetup.IDFindCustomerByANI(dnis,ani,lob,searchType,entityCode);
		
		assertTrue(true);
		
		// Fraud Retrieve Arrangement Details
		accessor = "TransactionHistoryRetrieveArrangementDetails";   

  		inputMap.put(Constants.INPUT_ACCOUNT_NUMBER, "4940045676195446");
  		inputMap.put(Constants.INPUT_ENTITY_CODE,"90");
  		
  		// Parse response
  		returnMap = ( CallSimulator.getResponseMap( Util.generateURL( accessor , inputMap ) ) );
  		
  		assertTrue(returnMap.get("returnCode").equals("0"));
  		assertTrue(returnMap.get("lostStolenAccountNumber").equals("4520333344445555"));
  	} 	 
	@Test
    public void IsLostStolen_4940045676191513() throws Throwable {

		HashMap<String, String> inputMap = new HashMap<String, String>();
		HashMap<String, String> returnMap = new HashMap<String, String>();
		
		// Set up call
		String dnis = "1070001";
		String ani = "5149047801";
		String lob = "Card";
		String searchType = "anything";
		String entityCode = "90";
		
		CallSimulator.Start();
		returnMap = CallSimulatorSetup.IDFindCustomerByANI(dnis,ani,lob,searchType,entityCode);
		
		// Fraud Retrieve Arrangement Details
		accessor = "TransactionHistoryRetrieveArrangementDetails";   

  		inputMap.put(Constants.INPUT_ACCOUNT_NUMBER, "4940045676191513");
  		inputMap.put(Constants.INPUT_ENTITY_CODE,"90");
  		
  		// Parse response
  		returnMap = ( CallSimulator.getResponseMap( Util.generateURL( accessor , inputMap ) ) );Util.WriteTofile(returnMap .toString(), "temp");
  		Util.WriteTofile(returnMap .toString(), "temp");
  		assertTrue(returnMap.get("returnCode").equals("0"));
  	    assertTrue(returnMap.get("lostStolenAccountNumber").equals("4940045676191513"));
  	} 	 
}