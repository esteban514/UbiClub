package ubi.club.services;

import java.sql.SQLException;

import javax.naming.NamingException;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import ubi.club.database.DataAccess;
import ubi.club.utils.GenerateHTML;

@Path("/feedback")
public class Feedback {

	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_HTML)
	public String giveFeedBack(@FormParam("session") String session, @FormParam("comment") String comment, @FormParam("rate") String rating) throws NamingException, ClassNotFoundException{
		
		//TODO GET ID FROM HHEADER
		String UbiUserId = "jeudinights";
		boolean success = true;
		/*	INSERT 
			We build the SQL query here with the URL parameters and the user id from the headers
			Note: The primary key is composed of the user and session thus enforcing the 
			"player can only leave one feedback per session" requirement
		*/
		String sqlQuery = "INSERT INTO ubiclub.feedback (`key`, comment, rate, user, session) VALUES('"+UbiUserId+"_"+session+"','"+comment+"',"+rating+",'"+UbiUserId+"','"+session+"')";
		
		System.out.println(sqlQuery);
		
		if (UbiUserId!=""&&UbiUserId!=null&&session!=null&&session!=""){
			try {
				DataAccess.runInsert(sqlQuery);
			} catch (SQLException e) {System.out.println(e);
				success = false;
			}			
		}
		
		String response = GenerateHTML.resultPage(success);
		return response;
	}	
}

