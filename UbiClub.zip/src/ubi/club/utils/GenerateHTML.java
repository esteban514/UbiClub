package ubi.club.utils;

public class GenerateHTML {

	public static String resultPage(boolean b){
		String output = "<html>";
		output+="<head>";
		output+="	<title>UbiClub</title>";
		output+="	<link rel=\"icon\" type=\"image/png\" href=\"http://localhost:8080/UbiClub/images/ef.ico\">";
		output+="	<link rel=\"stylesheet\" type=\"text/css\" href=\"http://localhost:8080/UbiClub//css/section.css\">";
		output+="	<link rel=\"stylesheet\" type=\"text/css\" href=\"http://localhost:8080/UbiClub/css/buttons.css\">";
		output+="</head>";		
		output+="<body>";
		output+="	<section>";
		output+="		<form action=\"../../UbiClub\">";
		output+="			<table>";
		output+="				<tr>";
		output+="					<td align=\"center\">";  
		output+="					</td>";
		if (b) {
			output+="				<td align=\"center\"><font color=\"white\">Feedback received</font>";
		}
		else{
			output+="				<td align=\"center\"><font color=\"white\">Sorry there was an issue</font>";
		}
		output+="					</td>";
		output+="				</tr>";
		output+="				<tr>";
		output+="					<td align=\"center\">";  
		output+="					</td>";
		output+="					<td align=\"center\">";  
		if (b) {
			output+="						<input class=\"button\" type=\"submit\" value=\"Back\" />";
		}
		else{
			output+="						<input class=\"button\" type=\"submit\" value=\"Try again\" />";
		}		
		output+="					</td>";
		output+="					<td align=\"center\">";  
		output+="					</td>";
		output+="				</tr>";
		output+="			</table>";
		output+="		</form>";
		output+="	</section>";
		output+="</body>";
		return output;
	}
	
	public static String displayPage(String[][] results){
		String output = "<html>";
		output+="<head>";
		output+="	<title>UbiClub</title>";
		output+="	<link rel=\"icon\" type=\"image/png\" href=\"http://localhost:8080/UbiClub/images/ef.ico\">";
		output+="	<link rel=\"stylesheet\" type=\"text/css\" href=\"http://localhost:8080/UbiClub//css/section.css\">";
		output+="	<link rel=\"stylesheet\" type=\"text/css\" href=\"http://localhost:8080/UbiClub/css/buttons.css\">";
		output+="</head>";		
		output+="<body>";
		output+="		<form action=\"../../UbiClub\">";
		output+="			<table>";
		output+="				<tr>";
		output+="				 	<th align=\"center\"><font color=\"black\">Comment</font></th>";
		output+="					<th align=\"center\"><font color=\"black\">Rate</font></th>";
		output+="					<th align=\"center\"><font color=\"black\">User</font></th>";
		output+="				</tr>";
		for (int i = 0; i < results.length; i++) {
			output+="				<tr>";
			if(results[i][0]!=null){
				output+="				<td align=\"center\"><font color=\"black\">"+results[i][0]+"</font></td>";
			}
			if(results[i][1]!=null){
				output+="				<td align=\"center\"><font color=\"black\">"+results[i][1]+"</font></td>";
			}
			if(results[i][2]!=null){
				output+="				<td align=\"center\"><font color=\"black\">"+results[i][2]+"</font></td>";
			}		
			output+="				</tr>";
		}
		output+="				<tr>";
		output+="					<td align=\"center\">";  
		output+="					</td>";
		output+="					<td align=\"center\">";  
		output+="						<input class=\"button\" type=\"submit\" value=\"Back\" />";
		output+="					</td>";
		output+="					<td align=\"center\">";  
		output+="					</td>";
		output+="				</tr>";
		output+="			</table>";
		output+="		</form>";
		output+="</body>";
		return output;
	}
}
