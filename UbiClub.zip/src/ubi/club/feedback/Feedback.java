package ubi.club.feedback;

import javax.xml.bind.annotation.XmlRootElement;

	@XmlRootElement
public class Feedback {

	private String session;
	//private String user;
	private String comment;
	private int rating;
	
	public Feedback(){
	}
	public Feedback(String session, String comment, int rating){
	}	
	public String getSession() {
		return session;
	}
	public void setSession(String session) {
		this.session = session;
	}
//	public String getUser() {
//		return user;
//	}
//	public void setUser(String user) {
//		this.user = user;
//	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}

}
