package ubi.club.database;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class DataAccess {
       


	private DataAccess(){  
    }   

	public static String runInsert(String selectQry)throws SQLException{

    	String response = "";
    	
    	try{
    		Context ctx = new InitialContext();
    		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/UBICLUB");
    		
    		Connection c = null;
    		Statement s = null;
    	   
    		c = ds.getConnection();
    	    s = c.createStatement();	
    	    
    	    s.execute(selectQry);

            s.close();
            c.close();
            
    	}catch(NamingException e){
    
    	}
		return response;
    }        
	public static String[][] runSelect(String selectQry)throws SQLException, NamingException{

    		Context ctx = new InitialContext();
    		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/UBICLUB");
   		
    		Connection c = null;
    		Statement s = null;
    		
    	   
    		c = ds.getConnection();
    	    s = c.createStatement();	
    	    
    	    ResultSet rs = s.executeQuery(selectQry);
    	    
    	    String[][] results = new String[15][3];
    	   
    	    int index=0;
    	    
    	    while (rs.next()) {
    	    	results[index][0]=rs.getString("comment");
    	    	results[index][1]=rs.getString("rate");
    	    	results[index][2]=rs.getString("user");
    	    	System.out.println(rs.getString("comment")+"+"+rs.getString("rate")+"+"+rs.getString("user"));
    	    	index++;
    	    }
    	    
            s.close();
            c.close();
            
            
    	return results;
    }        
}

