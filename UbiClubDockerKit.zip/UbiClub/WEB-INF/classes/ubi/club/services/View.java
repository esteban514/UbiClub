package ubi.club.services;

import java.sql.SQLException;

import javax.naming.NamingException;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import ubi.club.database.DataAccess;
import ubi.club.utils.GenerateHTML;

@Path("/view")
public class View {
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_HTML)
	public String getGreetings(@FormParam("session")  String session ) throws SQLException, NamingException{
		
		//TODO GET ID FROM HHEADER
		String UbiUserId = "jeudinights";
		
		String[][] results = {{""}};
		String sqlQuery = "SELECT * FROM ubiclub.feedback WHERE session='"+session+"' ORDER BY rate";
		
		if (UbiUserId!=""&&UbiUserId!=null&&session!=null&&session!=""){
			results = DataAccess.runSelect(sqlQuery);			
		}

		String response = GenerateHTML.displayPage(results);
		return response;
	}
	
}
